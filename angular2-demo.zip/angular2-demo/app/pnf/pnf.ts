import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router'
@Component({
  templateUrl: 'app/pnf/pnf.html', 
})
export class pnfComponent {
}
    