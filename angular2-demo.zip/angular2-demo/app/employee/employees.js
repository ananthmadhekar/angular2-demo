"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var employees_service_1 = require("./employees.service");
var EmployeesComponent = /** @class */ (function () {
    function EmployeesComponent(_employeeService) {
        this._employeeService = _employeeService;
        //employees: any[] = [
        //    { id: 101, firstName: 'Virat', lastName: 'Kohli', salary: 10000, dob: '01/01/1988' },
        //    { id: 102, firstName: 'Rohit', lastName: 'Sharma', salary: 20000, dob: '01/01/1988' },
        //    { id: 103, firstName: 'Shikhar', lastName: 'Dhawan', salary: 30000, dob: '01/01/1988' },
        //    { id: 104, firstName: 'Ambati', lastName: 'Rayudu', salary: 40000, dob: '01/01/1988' },
        //    { id: 105, firstName: 'MS', lastName: 'Dhoni', salary: 50000, dob: '01/01/1988' }
        //];
        this.employees = null;
        this.employees = this._employeeService.getEmployees();
    }
    EmployeesComponent = __decorate([
        core_1.Component({
            selector: 'employees',
            templateUrl: 'app/employee/employees.html',
            providers: [employees_service_1.EmployeesService]
        }),
        __metadata("design:paramtypes", [employees_service_1.EmployeesService])
    ], EmployeesComponent);
    return EmployeesComponent;
}());
exports.EmployeesComponent = EmployeesComponent;
//# sourceMappingURL=employees.js.map