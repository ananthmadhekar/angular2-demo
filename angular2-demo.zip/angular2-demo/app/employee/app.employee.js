"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var EmpComponent = /** @class */ (function () {
    function EmpComponent() {
        this.name = "ananth";
        this.designation = "developer";
        this.salary = 9000;
        this.colspan = 2;
        this.empdetailsclass = "class1";
        this.class3touse = false;
        this.showEmpDetails = false;
        this.btnText = "Show Employee Details";
        this.val = "Ananth Madhekar";
    }
    EmpComponent.prototype.displayEmpDetails = function () {
        this.showEmpDetails = !this.showEmpDetails;
        this.btnText = this.showEmpDetails ? 'Hide Employee Details' : 'Show Employee Details';
    };
    ;
    EmpComponent = __decorate([
        core_1.Component({
            selector: 'employee',
            templateUrl: 'app/employee/app.employee.html',
            styleUrls: ['app/employee/app.employee.css']
        })
    ], EmpComponent);
    return EmpComponent;
}());
exports.EmpComponent = EmpComponent;
//# sourceMappingURL=app.employee.js.map