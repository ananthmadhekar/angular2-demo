"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var EmployeesService = /** @class */ (function () {
    function EmployeesService() {
    }
    EmployeesService.prototype.getEmployees = function () {
        return [
            { id: 101, firstName: 'Virat', lastName: 'Kohli', salary: 10000, dob: '01/01/1988' },
            { id: 102, firstName: 'Rohit', lastName: 'Sharma', salary: 20000, dob: '01/01/1988' },
            { id: 103, firstName: 'Shikhar', lastName: 'Dhawan', salary: 30000, dob: '01/01/1988' },
            { id: 104, firstName: 'Ambati', lastName: 'Rayudu', salary: 40000, dob: '01/01/1988' },
            { id: 105, firstName: 'MS', lastName: 'Dhoni', salary: 50000, dob: '01/01/1988' }
        ];
    };
    EmployeesService = __decorate([
        core_1.Injectable()
    ], EmployeesService);
    return EmployeesService;
}());
exports.EmployeesService = EmployeesService;
//# sourceMappingURL=employees.service.js.map