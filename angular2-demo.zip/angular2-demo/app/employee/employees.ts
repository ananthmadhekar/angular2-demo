﻿import { Component } from '@angular/core'
import { EmployeesService } from './employees.service'
import { iEmployee } from './IEmployee'

@Component({
    selector: 'employees',
    templateUrl: 'app/employee/employees.html',
    providers: [EmployeesService]
})
export class EmployeesComponent {
    //employees: any[] = [
    //    { id: 101, firstName: 'Virat', lastName: 'Kohli', salary: 10000, dob: '01/01/1988' },
    //    { id: 102, firstName: 'Rohit', lastName: 'Sharma', salary: 20000, dob: '01/01/1988' },
    //    { id: 103, firstName: 'Shikhar', lastName: 'Dhawan', salary: 30000, dob: '01/01/1988' },
    //    { id: 104, firstName: 'Ambati', lastName: 'Rayudu', salary: 40000, dob: '01/01/1988' },
    //    { id: 105, firstName: 'MS', lastName: 'Dhoni', salary: 50000, dob: '01/01/1988' }
    //];

    employees: iEmployee[] = null;
    constructor(private _employeeService: EmployeesService) {
        this.employees = this._employeeService.getEmployees();
    }

}