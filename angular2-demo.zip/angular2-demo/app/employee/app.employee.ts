﻿import { Component } from '@angular/core';
@Component({
    selector: 'employee',
    templateUrl: 'app/employee/app.employee.html',
    styleUrls: ['app/employee/app.employee.css']
})
export class EmpComponent {
    name: string = "ananth";
    designation: string = "developer";
    salary: number = 9000;
    colspan: number = 2;
    empdetailsclass: string = "class1";
    class3touse: string = false;

    showEmpDetails: boolean = false;
    btnText: string = "Show Employee Details";
    val: string = "Ananth Madhekar";

    displayEmpDetails(): void {
        this.showEmpDetails = !this.showEmpDetails;
        this.btnText = this.showEmpDetails ? 'Hide Employee Details' : 'Show Employee Details';
    };
}
