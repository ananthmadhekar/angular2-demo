﻿
export interface iEmployee {
    id: string = "";
    firstName: string = "";
    lastName: string = "";
    salary: number = 0;
    dob: string = "";
}