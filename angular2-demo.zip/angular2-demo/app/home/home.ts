import { Component } from '@angular/core';
import { Router, RouterModule, __router_private__ } from '@angular/router'
@Component({
  templateUrl: 'app/home/home.html', 
})
export class HomeComponent {
    constructor(private _router: Router) { }

    goToEmployee(): void {
        this._router.navigate(['/employee']);
    };
}
    