import { Component } from '@angular/core';
@Component({
  selector: 'msg-app',
  templateUrl: 'app/app.component.html', 
  styleUrls: ['app/app.component.css']
})
export class AppComponent {
    message: string = "Just learning angular2";
    multiple: number = 60;
}
    