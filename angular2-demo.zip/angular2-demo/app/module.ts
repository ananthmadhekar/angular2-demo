import {NgModule}      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { APP_BASE_HREF } from '@angular/common';
import { RouterModule, Routes } from '@angular/router'

import { AppComponent } from './app.component';
import { EmpComponent } from './employee/app.employee';
import { EmployeesComponent } from './employee/employees';
import { EmployeeSalaryPipe } from './employee/empSalaryPipe';
import { HomeComponent } from './home/home';
import { pnfComponent } from './pnf/pnf';

import { FormsModule } from '@angular/forms'

const appRoutes: Routes = [
    { path: 'employee', component: EmployeesComponent },
    { path: '*/employee', component: EmployeesComponent },
    { path: 'home', component: HomeComponent },
    { path: '/home', component: HomeComponent },
    { path: '', redirectTo: '/employee', pathMatch: 'full' },
    { path: '**', component: pnfComponent }
];


@NgModule({
    imports: [BrowserModule, FormsModule, RouterModule.forRoot(appRoutes)],
    declarations: [AppComponent, EmpComponent, EmployeesComponent, EmployeeSalaryPipe, HomeComponent, pnfComponent],
    bootstrap: [AppComponent],
    providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
})
export class AppModule { }
