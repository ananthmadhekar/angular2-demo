"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var common_1 = require("@angular/common");
var router_1 = require("@angular/router");
var app_component_1 = require("./app.component");
var app_employee_1 = require("./employee/app.employee");
var employees_1 = require("./employee/employees");
var empSalaryPipe_1 = require("./employee/empSalaryPipe");
var home_1 = require("./home/home");
var pnf_1 = require("./pnf/pnf");
var forms_1 = require("@angular/forms");
var appRoutes = [
    { path: 'employee', component: employees_1.EmployeesComponent },
    { path: '*/employee', component: employees_1.EmployeesComponent },
    { path: 'home', component: home_1.HomeComponent },
    { path: '/home', component: home_1.HomeComponent },
    { path: '', redirectTo: '/employee', pathMatch: 'full' },
    { path: '**', component: pnf_1.pnfComponent }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, router_1.RouterModule.forRoot(appRoutes)],
            declarations: [app_component_1.AppComponent, app_employee_1.EmpComponent, employees_1.EmployeesComponent, empSalaryPipe_1.EmployeeSalaryPipe, home_1.HomeComponent, pnf_1.pnfComponent],
            bootstrap: [app_component_1.AppComponent],
            providers: [{ provide: common_1.APP_BASE_HREF, useValue: '/' }]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=module.js.map